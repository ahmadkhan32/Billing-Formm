﻿Public Class Form1
    'Declare module()-level constants.
    Const TAX_RATE_Decimal As Decimal = 0.08D
    Const CAPPUCCINO_PRICE_Decimal As Decimal = 2D
    Const ESPRESSO_PRICE_Decimal As Decimal = 2.25D
    Const LATTE_PRICE_Decimal As Decimal = 1.75D
    Const ICED_PRICE_Decimal As Decimal = 2.5D

    ' Declare module-level variables for summary information.
    Private SubtotalDecimal, TotalDecimal, GrandTotalDecimal As Decimal
    Private CustomerCountInteger As Integer

    Private Sub ClearButton_Click(sender As Object, e As EventArgs) Handles ClearButton.Click
        ' Clear the appropriate controls.
        CappuccinoRadioButton.Checked = True ' All others are false.
        ItemAmountTextBox.Clear()
        With QuantityTextBox
            .Clear()
            .Focus()
        End With
    End Sub

    Private Sub NewOrderButton_Click(sender As Object, e As EventArgs) Handles NewOrderButton.Click
        Dim ReturnDialogResult As DialogResult
        Dim MessageString As String
        ' Confirm clear of current order.
        MessageString = "Clear the current order figures?"
        ReturnDialogResult = MessageBox.Show(MessageString, "Clear Order",
        MessageBoxButtons.YesNo, MessageBoxIcon.Question,
        MessageBoxDefaultButton.Button2)
        If ReturnDialogResult = DialogResult.Yes Then ' User said Yes.

        End If
        ClearButton_Click(sender, e) ' Clear the screen fields.
        SubTotalTextBox.Clear()
        TaxTextBox.Clear()
        TotalTextBox.Clear()
        ' Add to Totals.
        ' Add only if not a new order/customer.
        If SubtotalDecimal <> 0 Then
            GrandTotalDecimal += TotalDecimal
            CustomerCountInteger += 1
            ' Reset totals for next customer.
            SubtotalDecimal = 0
            TotalDecimal = 0
        End If
        ' Clear appropriate display items and enable check box.
        With TaxCheckBox
            .Enabled = True
            .Checked = False
        End With
        ClearButton.Enabled = False
        NewOrderButton.Enabled = False
    End Sub

    Private Sub SummaryButton_Click(sender As Object, e As EventArgs) Handles SummaryButton.Click
        ' Calculate the average and display the totals.
        Dim AverageDecimal As Decimal
        Dim MessageString As String
        If TotalDecimal <> 0 Then
            ' Make sure last order is counted.
            NewOrderButton_Click(sender, e)
        End If
        If CustomerCountInteger > 0 Then
            ' Calculate the average.
            AverageDecimal = GrandTotalDecimal / CustomerCountInteger
            ' Concatenate the message string.
            MessageString = "Number of Orders: " _
            & CustomerCountInteger.ToString() _
            & Environment.NewLine & Environment.NewLine _
            & "Total Sales: " & GrandTotalDecimal.ToString("C") _
            & Environment.NewLine & Environment.NewLine _
            & "Average Sale: " & AverageDecimal.ToString("C")
            MessageBox.Show(MessageString, "Coffee Sales Summary",
            MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageString = "No sales data to summarize."
            MessageBox.Show(MessageString, "Coffee Sales Summary",
            MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Me.Close()
    End Sub
    Private Sub CalculateButton_Click(sender As Object, e As EventArgs) Handles CalculateButton.Click
        ' Calculate and display the current amounts and add to totals.
        Dim PriceDecimal, TaxDecimal, ItemAmountDecimal As Decimal
        Dim QuantityInteger As Integer
        ' Find the price.
        If CappuccinoRadioButton.Checked Then

            PriceDecimal = CAPPUCCINO_PRICE_Decimal
        ElseIf EspressoRadioButton.Checked Then
            PriceDecimal = ESPRESSO_PRICE_Decimal
        ElseIf LatteRadioButton.Checked Then
            PriceDecimal = LATTE_PRICE_Decimal
        ElseIf IcedCappuccinoRadioButton.Checked Or
        IcedLatteRadioButton.Checked Then
            PriceDecimal = ICED_PRICE_Decimal
        End If
        ' Calculate extended price and add to order total.
        Try
            QuantityInteger = Integer.Parse(QuantityTextBox.Text)
            ItemAmountDecimal = PriceDecimal * QuantityInteger
            SubtotalDecimal += ItemAmountDecimal
            If TaxCheckBox.Checked Then
                TaxDecimal = SubtotalDecimal * TAX_RATE_Decimal
            Else
                TaxDecimal = 0
            End If
            TotalDecimal = SubtotalDecimal + TaxDecimal
            ItemAmountTextBox.Text = ItemAmountDecimal.ToString("C")
            SubTotalTextBox.Text = SubtotalDecimal.ToString("N")
            TaxTextBox.Text = TaxDecimal.ToString("N")
            TotalTextBox.Text = TotalDecimal.ToString("C")
            ' Allow a change only for new order.
            TaxCheckBox.Enabled = False
            ' Allow Clear after an order is begun.
            ClearButton.Enabled = True
            NewOrderButton.Enabled = True
        Catch QuantityException As FormatException
            MessageBox.Show("Quantity must be numeric.",
"Data Entry Error", MessageBoxButtons.OK,
MessageBoxIcon.Information)
            With QuantityTextBox
                .Focus()
                .SelectAll()
            End With
        End Try
    End Sub
End Class
